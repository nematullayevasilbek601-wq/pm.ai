import os
import anthropic
from dotenv import load_dotenv

load_dotenv()

client = anthropic.Anthropic(api_key=os.getenv("ANTHROPIC_API_KEY"))
history = []

print("Chatbot tayyor! Chiqish uchun 'exit' deb yozing.")

while True:
    user_input = input("Siz: ")
    if user_input.lower() == "exit":
        break

    history.append({"role": "user", "content": user_input})

    response = client.messages.create(
        model="claude-sonnet-5-5",
        max_tokens=1000,
        system="Sen foydali yordamchisan. O'zbek tilida javob ber.",
        messages=history,
    )

    answer = response.content[0].text
    history.append({"role": "assistant", "content": answer})
    print("AI:", answer)
