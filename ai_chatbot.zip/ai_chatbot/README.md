# AI Chatbot

## O'rnatish
1. `.env.example` faylini `.env` deb nomlang va ichiga API kalitingizni yozing
   (kalit: https://console.anthropic.com)
2. Kutubxonalarni o'rnating:
   pip install -r requirements.txt
3. Ishga tushiring:
   python chatbot.py
